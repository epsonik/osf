CREATE VIEW history AS
  (SELECT
     `osf`.`osf`.`id`                  AS `id`,
     `osf`.`osf`.`wnId`                AS `wnId`,
     `osf`.`osf`.`nazwasekcji`         AS `nazwasekcji`,
     `osf`.`osf`.`wartosc`             AS `wartosc`,
     (CASE WHEN (`osf`.`osf`.`wnId` = 'a')
       THEN `osf`.`osf`.`wartosc` END) AS `a`,
     (CASE WHEN (`osf`.`osf`.`wnId` = 'b')
       THEN `osf`.`osf`.`wartosc` END) AS `b`
   FROM `osf`.`osf`);
